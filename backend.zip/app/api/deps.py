from typing import Annotated
from uuid import UUID

from fastapi import Depends, Header, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.database import get_db
from app.core.security import decodificar_token, verificar_api_key
from app.modelos.empresa_cliente import EmpresaCliente
from app.modelos.tecnico import Tecnico
from app.modelos.usuario import Usuario
from app.repositorios.empresa_cliente import EmpresaClienteRepositorio
from app.repositorios.usuario import UsuarioRepositorio

oauth2_scheme = OAuth2PasswordBearer(tokenUrl=f"{settings.API_V1_PREFIX}/autenticacion/login")
SesionDep = Annotated[AsyncSession, Depends(get_db)]
TokenDep = Annotated[str, Depends(oauth2_scheme)]


async def obtener_usuario_actual(session: SesionDep, token: TokenDep) -> Usuario:
    credenciales_error = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="No se pudieron validar las credenciales",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = decodificar_token(token)
        usuario_id = UUID(str(payload.get("sub")))
    except (TypeError, ValueError):
        raise credenciales_error from None

    usuario = await UsuarioRepositorio(session).obtener_por_id_con_autenticacion(usuario_id)
    if usuario is None or not usuario.esta_activo:
        raise credenciales_error
    return usuario


UsuarioActualDep = Annotated[Usuario, Depends(obtener_usuario_actual)]


def requerir_admin(usuario_actual: UsuarioActualDep) -> Usuario:
    if not any(usuario_rol.rol.nombre == "ADMIN" for usuario_rol in usuario_actual.roles):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Se requieren permisos de administrador",
        )
    return usuario_actual


AdminDep = Annotated[Usuario, Depends(requerir_admin)]


def requerir_tecnico(usuario_actual: UsuarioActualDep) -> Tecnico:
    if usuario_actual.tecnico is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Se requiere perfil de tecnico",
        )
    return usuario_actual.tecnico


TecnicoActualDep = Annotated[Tecnico, Depends(requerir_tecnico)]


def usuario_es_admin(usuario: Usuario) -> bool:
    return any(usuario_rol.rol.nombre == "ADMIN" for usuario_rol in usuario.roles)


def usuario_es_empresa_cliente(usuario: Usuario) -> bool:
    return any(usuario_rol.rol.nombre == "EMPRESA_CLIENTE" for usuario_rol in usuario.roles)


def requerir_empresa_cliente(usuario_actual: UsuarioActualDep) -> EmpresaCliente:
    if (
        not usuario_es_empresa_cliente(usuario_actual)
        or usuario_actual.empresa_cliente is None
        or not usuario_actual.empresa_cliente.esta_activa
    ):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Se requiere perfil de empresa cliente activa",
        )
    return usuario_actual.empresa_cliente


EmpresaClienteActualDep = Annotated[EmpresaCliente, Depends(requerir_empresa_cliente)]


async def obtener_empresa_cliente_por_api_key(
    session: SesionDep, x_api_key: Annotated[str | None, Header()] = None
) -> EmpresaCliente:
    if not x_api_key:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="API key requerida",
        )

    empresas = await EmpresaClienteRepositorio(session).listar_activas_con_api_key()
    for empresa in empresas:
        if empresa.hash_api_key and verificar_api_key(x_api_key, empresa.hash_api_key):
            return empresa

    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="API key invalida",
    )


EmpresaClienteApiKeyDep = Annotated[EmpresaCliente, Depends(obtener_empresa_cliente_por_api_key)]
